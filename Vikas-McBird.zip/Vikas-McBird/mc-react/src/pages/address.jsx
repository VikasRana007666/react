import Header from "../components/Header";
import Footer from "../components/Footer";

import React, { useState } from "react";
import axios from "../../lib/axiosInstance";
import { useNavigate } from "react-router-dom";

export default function Address() {
  const navigate = useNavigate();

  const [addresses, setAddresses] = useState([
    { address1: "", address2: "", address3: "" },
  ]);

  const handleAddAddress = () => {
    if (addresses.length < 3) {
      setAddresses([
        ...addresses,
        { address1: "", address2: "", address3: "" },
      ]);
    }
  };

  const handleRemoveAddress = () => {
    setAddresses(addresses.slice(0, -1));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("/add_address", {
        user_id: localStorage.getItem("user_id"),
        addresses: addresses,
      });
      console.log(res.data.status);
      if (res.data.status == true) {
        navigate("/thank-you");
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleChange = (index, e) => {
    const { name, value } = e.target;
    const updatedAddresses = [...addresses];
    updatedAddresses[index][name] = value;
    setAddresses(updatedAddresses);
  };

  return (
    <div>
      <Header></Header>
      <section className="bnrsection">
        <div className="container">
          <div className="offset-lg-2 col-lg-8 offset-md-1 col-md-10 col-12 text-center">
            <div className="formpart">
              <form onSubmit={handleSubmit}>
                {addresses.map((address, index) => (
                  <div key={index}>
                    <div className="mb-3 text-start">
                      <label className="form-label">
                        Previous Address {index + 1}
                      </label>
                      <input
                        required
                        type="text"
                        className="form-control mb-3"
                        placeholder="Address line 1"
                        name="address1"
                        value={address.address1}
                        onChange={(e) => handleChange(index, e)}
                      />
                      <input
                        required
                        type="text"
                        className="form-control mb-3"
                        placeholder="Address line 2"
                        name="address2"
                        value={address.address2}
                        onChange={(e) => handleChange(index, e)}
                      />
                      <input
                        required
                        type="text"
                        className="form-control mb-3"
                        placeholder="Address line 3"
                        name="address3"
                        value={address.address3}
                        onChange={(e) => handleChange(index, e)}
                      />
                    </div>
                    {index === addresses.length - 1 && (
                      <div>
                        {addresses.length < 3 && (
                          <>
                            <button
                              className="me-2 btn btn-primary"
                              type="button"
                              onClick={handleAddAddress}
                            >
                              Add Address
                            </button>
                            {addresses.length > 1 && (
                              <button
                                className="me-2 btn btn-danger"
                                type="button"
                                onClick={handleRemoveAddress}
                              >
                                Remove Address
                              </button>
                            )}
                          </>
                        )}
                        <>
                          {addresses.length > 2 && (
                            <button
                              className="me-2 btn btn-danger"
                              type="button"
                              onClick={handleRemoveAddress}
                            >
                              Remove Address
                            </button>
                          )}
                        </>
                      </div>
                    )}
                  </div>
                ))}
                <button className="me-2 btn btn-success" type="submit">
                  Submit
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
      <Footer></Footer>
    </div>
  );
}
