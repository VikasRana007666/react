import Header from "../components/Header";
import Footer from "../components/Footer";
import axios from "../../lib/axiosInstance";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";

export default function SignUp() {
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");

  const [showAlert, setShowAlert] = useState(false);
  const [message, setMessage] = useState("");

  const handleSubmit = async (event) => {
    event.preventDefault();
    const data = {
      email,
      phone,
      user_id: localStorage.getItem("user_id"),
    };
    axios
      .post("/sign_up_form", data)
      .then((response) => {
        // console.log(response);
        if (response.data.status == true) {
          // redirect to /sign-up without refreshing the page
          navigate("/check");
        } else if (response.data.status == false) {
          setShowAlert(true);
          setMessage(response.data.message);
          setTimeout(() => {
            setShowAlert(false);
          }, 2000);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <div>
      <Header></Header>
      <section className="bnrsection">
        <div className="offset-lg-2 col-lg-8 offset-md-1 col-md-10 col-12 text-center">
          <div className="formpart">
            <form onSubmit={handleSubmit}>
              <div id="slide02">
                <h3>Enter Your Contact Details</h3>

                {showAlert && (
                  <div className="alert alert-danger" role="alert">
                    {message}
                  </div>
                )}

                <div className="mb-3 text-start">
                  <label className="form-label">Email Address</label>
                  <input
                    required
                    type="email"
                    className="form-control"
                    id="FormControlInput4"
                    placeholder="Email Address"
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                  />
                </div>
                <div className="mb-3 text-start">
                  <label className="form-label">Phone Number</label>
                  <input
                    required
                    maxLength="10"
                    type="text"
                    className="form-control"
                    id="FormControlInput5"
                    placeholder="Phone Number"
                    value={phone}
                    onChange={(event) => setPhone(event.target.value)}
                    onKeyDown={(event) => {
                      const regex = /^[0-9\b]+$/;
                      if (!regex.test(event.key)) {
                        event.preventDefault();
                      }
                    }}
                  />
                </div>
                <div className="mb-3 text-center">
                  <button
                    type="submit"
                    className="btn btn-success"
                    id="submit_claim"
                  >
                    Submit
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </section>
      <Footer></Footer>
    </div>
  );
}
