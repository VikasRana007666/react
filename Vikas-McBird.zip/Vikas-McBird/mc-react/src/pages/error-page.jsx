import Header from "../components/Header";
import Footer from "../components/Footer";

export default function ErrorPage() {
  return (
    <div>
      <Header></Header>
      <h1 className="center">asjdflajldf</h1>
      <Footer></Footer>
    </div>
  );
}
