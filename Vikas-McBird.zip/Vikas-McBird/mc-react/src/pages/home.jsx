import Header from "../components/Header";
import Footer from "../components/Footer";
import axios from "../../lib/axiosInstance";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";

export default function Home() {
  // Set Browser Type
  const [browser, setBrowser] = useState("");

  useEffect(() => {
    const userAgent = window.navigator.userAgent;
    let tempBrowser;

    if (userAgent.indexOf("Firefox") > -1) {
      tempBrowser = "Mozilla Firefox";
    } else if (
      userAgent.indexOf("Opera") > -1 ||
      userAgent.indexOf("OPR") > -1
    ) {
      tempBrowser = "Opera";
    } else if (userAgent.indexOf("Trident") > -1) {
      tempBrowser = "Microsoft Internet Explorer";
    } else if (userAgent.indexOf("Edge") > -1) {
      tempBrowser = "Microsoft Edge";
    } else if (userAgent.indexOf("Chrome") > -1) {
      tempBrowser = "Google Chrome";
    } else if (userAgent.indexOf("Safari") > -1) {
      tempBrowser = "Apple Safari";
    } else {
      tempBrowser = "unknown";
    }

    setBrowser(tempBrowser);
  }, []);

  //
  const navigate = useNavigate();

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [day, setDay] = useState("");
  const [month, setMonth] = useState("");
  const [year, setYear] = useState("");

  const [days, setDays] = useState([]);
  const [months, setMonths] = useState([]);
  const [years, setYears] = useState([]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    const data = {
      first_name: firstName,
      last_name: lastName,
      day,
      month,
      year,
      browser,
    };
    axios
      .post("/home_form", data)
      .then((response) => {
        // console.log(response.data);
        if (response.data.status == true) {
          const data = response.data.data;
          // console.log(data.id);
          localStorage.setItem("user_id", data.id);
          // redirect to /sign-up without refreshing the page
          navigate("/sign-up");
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  useEffect(() => {
    axios
      .get("/day_month_year")
      .then((response) => {
        const data = response.data;

        setDays(data.data.days);
        setMonths(data.data.months);
        setYears(data.data.years);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  return (
    <div>
      <Header></Header>
      <section className="bnrsection">
        <div className="container-fluid">
          <div className="row">
            <div className="col-lg-12 p-0">
              <img src="dist/img/bnr.jpg" alt="" />
            </div>
          </div>
        </div>

        <div className="container">
          <div className="row">
            <div className="offset-lg-1 col-lg-10 col-md-12 col-12 text-center">
              <h1>
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry.
              </h1>
              <p>
                Lorem Ipsum has been the industry's standard dummy text ever
                since the 1500s, when an unknown printer took a galley of type
                and scrambled it to make a type specimen book. It has survived
                not only five centuries, but also the leap into electronic
                typesetting, remaining essentially unchanged.
              </p>
            </div>
            <div className="offset-lg-2 col-lg-8 offset-md-1 col-md-10 col-12 text-center">
              <div className="formpart">
                <form onSubmit={handleSubmit}>
                  <div id="slide01">
                    <h3>Enter Your Personal Details</h3>
                    <div className="mb-3 text-start">
                      <label className="form-label">First Name</label>
                      <input
                        required
                        type="text"
                        className="form-control"
                        id="FormControlInput1"
                        placeholder="First Name"
                        value={firstName}
                        onChange={(event) => setFirstName(event.target.value)}
                      />
                    </div>
                    <div className="mb-3 text-start">
                      <label className="form-label">Last Name</label>
                      <input
                        required
                        type="text"
                        className="form-control"
                        id="FormControlInput2"
                        placeholder="Last Name"
                        value={lastName}
                        onChange={(event) => setLastName(event.target.value)}
                      />
                    </div>
                    <div className="mb-3 text-start">
                      <label className="form-label">
                        Enter Your Date of Birth
                      </label>
                      <fieldset>
                        <legend> Date Of Birth</legend>
                        <div className="row">
                          <div className="form-group col-lg-4 col-md-4 col-sm-4 col-12 ">
                            <select
                              required
                              name="lstDobDay"
                              id="lstDobDay"
                              className="form-control watermark"
                              value={day}
                              onChange={(event) => setDay(event.target.value)}
                            >
                              <option disabled value="">
                                Day{" "}
                              </option>
                              {days.map((day) => (
                                <option key={day} value={day}>
                                  {day}
                                </option>
                              ))}
                            </select>

                            <span
                              id="dobDay_err"
                              className="error_msg error"
                            ></span>
                          </div>
                          <div className="form-group col-lg-4 col-md-4 col-sm-4 col-12 ">
                            <select
                              required
                              name="lstDobMonth"
                              id="lstDobMonth"
                              className="form-control watermark"
                              value={month}
                              onChange={(event) => setMonth(event.target.value)}
                            >
                              <option disabled value="">
                                Month{" "}
                              </option>
                              {months.map((month) => (
                                <option key={month.id} value={month.id}>
                                  {month.month}
                                </option>
                              ))}
                            </select>

                            <span
                              id="dobMonth_err"
                              className="error_msg"
                            ></span>
                          </div>
                          <div className="form-group col-lg-4 col-md-4 col-sm-4 col-12">
                            <select
                              required
                              name="lstDobYear"
                              id="lstDobYear"
                              className="form-control"
                              value={year}
                              onChange={(event) => setYear(event.target.value)}
                            >
                              <option disabled value="">
                                Year
                              </option>
                              {years.map((year) => (
                                <option key={year.year} value={year.year}>
                                  {year.year}
                                </option>
                              ))}
                            </select>

                            <span id="dobYear_err" className="error_msg"></span>
                          </div>
                          <span id="dob_final_err" className="error_msg"></span>
                        </div>
                      </fieldset>
                    </div>
                    <div className="mb-3 text-center">
                      <button type="submit" className="btn btn-warning next01">
                        Next
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
      <Footer></Footer>
    </div>
  );
}
