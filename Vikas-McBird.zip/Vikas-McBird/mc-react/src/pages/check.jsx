import Header from "../components/Header";
import Footer from "../components/Footer";
import React, { useState } from "react";
import axios from "../../lib/axiosInstance";
import { Link, useNavigate } from "react-router-dom";

export default function Check() {
  const navigate = useNavigate();

  const handleChange = (event) => {
    if (event.target.value == "no") {
      navigate("/thank-you");
    } else {
      navigate("/address");
    }
  };

  return (
    <div>
      <Header></Header>
      <section className="bnrsection">
        <div className="row">
          <div className="offset-lg-1 col-lg-10 col-md-12 col-12 text-center">
            <h1>
              Hi <span>username</span> Lorem Ipsum is simply dummy text of the
              printing and typesetting industry.
            </h1>
            <p>
              Lorem Ipsum has been the industry's standard dummy text ever since
              the 1500s, when an unknown printer took a galley of type and
              scrambled it to make a type specimen book. It has survived not
              only five centuries, but also the leap into electronic
              typesetting, remaining essentially unchanged.
            </p>
          </div>

          {/* ksfjlalf */}
          <div className="offset-lg-2 col-lg-8 offset-md-1 col-md-10 col-12 text-center">
            <div className="formpart">
              <form>
                <div id="slide03">
                  <h3>Do you have a Previous Address?</h3>
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      id="yes"
                      type="radio"
                      value="yes"
                      onChange={handleChange}
                    />
                    <label htmlFor="yes" className="form-check-label next02">
                      Yes
                    </label>
                  </div>
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      id="no"
                      type="radio"
                      value="no"
                      onChange={handleChange}
                    />
                    <label htmlFor="no" className="form-check-label tothank">
                      No
                    </label>
                  </div>
                </div>
              </form>
            </div>
          </div>
          {/* end */}
        </div>
      </section>
      <Footer></Footer>
    </div>
  );
}
