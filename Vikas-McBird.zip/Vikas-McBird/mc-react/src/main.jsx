import React from "react";
import ReactDOM from "react-dom/client";
import {
  BrowserRouter,
  RouterProvider,
  createBrowserRouter,
} from "react-router-dom";

// Script and Style
import "./index.css";

// Pages
import Home from "./pages/home";
import ErrorPage from "./pages/error-page";
import SignUp from "./pages/sign-up";
import ThankYou from "./pages/thank-you";
import Address from "./pages/address";
import Check from "./pages/check";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Home />,
    errorElement: <ErrorPage />,
  },
  {
    path: "/sign-up",
    element: <SignUp />,
    errorElement: <ErrorPage />,
  },
  {
    path: "/thank-you",
    element: <ThankYou />,
    errorElement: <ErrorPage />,
  },
  {
    path: "/address",
    element: <Address />,
    errorElement: <ErrorPage />,
  },
  {
    path: "/check",
    element: <Check />,
    errorElement: <ErrorPage />,
  },
]);

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);
