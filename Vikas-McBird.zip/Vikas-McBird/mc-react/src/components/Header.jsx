import { BrowserRouter, Link, NavLink } from "react-router-dom";

export default function Header() {
  return (
    <div>
      <header>
        <div className="container">
          <div className="row">
            <div className="col-lg-12 col-12 text-center">
              <img src="dist/img/logo.png" alt="" />
            </div>
          </div>
        </div>
      </header>
      {/* <nav className="navbar navbar-expand-lg bg-body-tertiary">
        <div className="container-fluid">
          <a className="navbar-brand" href="#">
            McBird
          </a>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <Link className="me-2" to="/">
                  Home
                </Link>
              </li>
              <li className="nav-item">
                <Link className="me-2" to="/sign-up">
                  Sign UP
                </Link>
              </li>
              <li className="nav-item">
                <Link className="me-2" to="/address">
                  Address
                </Link>
              </li>
              <li className="nav-item">
                <Link className="me-2" to="/thank-you">
                  Thank You
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav> */}
    </div>
  );
}
